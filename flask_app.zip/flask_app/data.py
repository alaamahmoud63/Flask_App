def Articles():
    articles = [
        {
            'id' : 1 ,
            'title':'Article One',
            'body': 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Explicabo veniam esse sequi non, dolorem laboriosam deserunt quod reprehenderit a molestias quibusdam beatae qui eaque aliquid vitae fugiat nulla adipisci. Earum.',
            'author':'Alaa Hmdallah',
            'creat_date':'18-5-2021'
        },
        {
            'id' : 2 ,
            'title':'Article Two',
            'body': 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Explicabo veniam esse sequi non, dolorem laboriosam deserunt quod reprehenderit a molestias quibusdam beatae qui eaque aliquid vitae fugiat nulla adipisci. Earum.',
            'author':'Hmdallah',
            'creat_date':'18-5-2021'
        },
        {
            'id' : 3 ,
            'title':'Article Three',
            'body': 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Explicabo veniam esse sequi non, dolorem laboriosam deserunt quod reprehenderit a molestias quibusdam beatae qui eaque aliquid vitae fugiat nulla adipisci. Earum.',
            'author':'Mahmoud Hmdallah',
            'creat_date':'18-5-2021'
        }
    ]
    return articles